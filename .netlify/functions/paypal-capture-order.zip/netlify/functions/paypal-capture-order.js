var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var paypal_capture_order_exports = {};
__export(paypal_capture_order_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(paypal_capture_order_exports);
var import_crypto = require("crypto");
const RATE_LIMIT_WINDOW_MS = 60 * 1e3;
const RATE_LIMIT_MAX_REQUESTS = 20;
const requestBuckets = /* @__PURE__ */ new Map();
function getHeader(event, key) {
  const headers = event?.headers || {};
  if (headers[key] !== void 0) return headers[key];
  const lower = key.toLowerCase();
  const found = Object.keys(headers).find((name) => name.toLowerCase() === lower);
  return found ? headers[found] : void 0;
}
function getClientIp(event) {
  const forwardedFor = String(getHeader(event, "x-forwarded-for") || "").split(",")[0].trim();
  const netlifyIp = String(getHeader(event, "x-nf-client-connection-ip") || "").trim();
  const fallback = String(event?.requestContext?.identity?.sourceIp || "").trim();
  return forwardedFor || netlifyIp || fallback || "unknown";
}
function isRateLimited(key, limit = RATE_LIMIT_MAX_REQUESTS, windowMs = RATE_LIMIT_WINDOW_MS) {
  const now = Date.now();
  const bucket = requestBuckets.get(key);
  if (!bucket || now - bucket.windowStart >= windowMs) {
    requestBuckets.set(key, { count: 1, windowStart: now });
    return false;
  }
  bucket.count += 1;
  return bucket.count > limit;
}
async function handler(event) {
  const requestOrigin = String(getHeader(event, "origin") || "");
  const allowedOrigins = /* @__PURE__ */ new Set([
    "https://nutrithrive.com.au",
    "https://www.nutrithrive.com.au"
  ]);
  const originAllowed = requestOrigin && allowedOrigins.has(requestOrigin);
  const baseHeaders = {
    "Content-Type": "application/json",
    "Vary": "Origin"
  };
  if (!originAllowed) {
    return {
      statusCode: 403,
      headers: baseHeaders,
      body: JSON.stringify({ error: "Origin not allowed" })
    };
  }
  const headers = {
    ...baseHeaders,
    "Access-Control-Allow-Origin": requestOrigin,
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const clientIp = getClientIp(event);
    if (isRateLimited(`paypal-capture:${clientIp}`)) {
      return {
        statusCode: 429,
        headers,
        body: JSON.stringify({ error: "Too many requests" })
      };
    }
    const { orderID, captureToken } = JSON.parse(event.body || "{}");
    const orderIdOk = typeof orderID === "string" && /^[A-Za-z0-9]{10,64}$/.test(orderID);
    if (!orderIdOk || !captureToken || typeof captureToken !== "string") {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Missing or invalid orderID/captureToken" })
      };
    }
    const base = (process.env.PAYPAL_BASE || "https://api-m.paypal.com").replace(/\/$/, "");
    const client = process.env.PAYPAL_CLIENT_ID;
    const secret = process.env.PAYPAL_CLIENT_SECRET;
    if (!client || !secret) {
      console.error("[paypal-capture-order] PayPal credentials not configured");
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({
          error: "Payment is temporarily unavailable. Please try again later."
        })
      };
    }
    const expected = (0, import_crypto.createHmac)("sha256", secret).update(String(orderID)).digest();
    const provided = Buffer.from(String(captureToken), "hex");
    if (provided.length !== expected.length || !(0, import_crypto.timingSafeEqual)(provided, expected)) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ error: "Invalid capture token" })
      };
    }
    const tokenRes = await fetch(`${base}/v1/oauth2/token`, {
      method: "POST",
      headers: {
        "Authorization": "Basic " + Buffer.from(`${client}:${secret}`).toString("base64"),
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: "grant_type=client_credentials"
    });
    const tokenData = await tokenRes.json();
    if (!tokenRes.ok) throw new Error(JSON.stringify(tokenData));
    const capRes = await fetch(`${base}/v2/checkout/orders/${orderID}/capture`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${tokenData.access_token}`
      }
    });
    const capture = await capRes.json();
    if (!capRes.ok) throw new Error(JSON.stringify(capture));
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(capture)
    };
  } catch (err) {
    console.error("[paypal-capture-order]", err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Unable to complete payment. Please try again."
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});

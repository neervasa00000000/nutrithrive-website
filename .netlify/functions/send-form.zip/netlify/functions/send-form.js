var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var send_form_exports = {};
__export(send_form_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(send_form_exports);
const RATE_LIMIT_WINDOW_MS = 60 * 1e3;
const RATE_LIMIT_MAX = 15;
const requestBuckets = /* @__PURE__ */ new Map();
const ALLOWED_ORIGINS = /* @__PURE__ */ new Set([
  "https://nutrithrive.com.au",
  "https://www.nutrithrive.com.au"
]);
function getHeader(event, key) {
  const headers = event?.headers || {};
  if (headers[key] !== void 0) return headers[key];
  const lower = key.toLowerCase();
  const found = Object.keys(headers).find((name) => name.toLowerCase() === lower);
  return found ? headers[found] : void 0;
}
function getClientIp(event) {
  const forwardedFor = String(getHeader(event, "x-forwarded-for") || "").split(",")[0].trim();
  const netlifyIp = String(getHeader(event, "x-nf-client-connection-ip") || "").trim();
  return forwardedFor || netlifyIp || "unknown";
}
function isRateLimited(key) {
  const now = Date.now();
  const bucket = requestBuckets.get(key);
  if (!bucket || now - bucket.windowStart >= RATE_LIMIT_WINDOW_MS) {
    requestBuckets.set(key, { count: 1, windowStart: now });
    return false;
  }
  bucket.count += 1;
  return bucket.count > RATE_LIMIT_MAX;
}
function corsHeaders(requestOrigin, baseHeaders) {
  if (requestOrigin && ALLOWED_ORIGINS.has(requestOrigin)) {
    return {
      ...baseHeaders,
      "Access-Control-Allow-Origin": requestOrigin,
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST, OPTIONS"
    };
  }
  return baseHeaders;
}
function cleanText(value, maxLen = 5e3) {
  return String(value ?? "").replace(/[\0\r]/g, "").trim().slice(0, maxLen);
}
async function verifyTurnstile(token, ip) {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret) return true;
  if (!token) return false;
  const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      secret,
      response: token,
      remoteip: ip
    })
  });
  const data = await res.json().catch(() => ({}));
  return data.success === true;
}
async function sendViaWeb3Forms({ accessKey, toEmail, formType, name, email, subject, message, pageUrl }) {
  const emailSubject = subject || (formType === "newsletter" ? "Newsletter subscription \u2014 NutriThrive" : "Website contact \u2014 NutriThrive");
  const body = [
    `Type: ${formType}`,
    `Name: ${name || "(not provided)"}`,
    `Email: ${email}`,
    pageUrl ? `Page: ${pageUrl}` : "",
    "",
    message || "(newsletter signup \u2014 no message)"
  ].filter(Boolean).join("\n");
  const res = await fetch("https://api.web3forms.com/submit", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({
      access_key: accessKey,
      subject: emailSubject,
      from_name: name || "NutriThrive website",
      email,
      message: body,
      to: toEmail
    })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.success === false) {
    throw new Error(data.message || `Web3Forms error (${res.status})`);
  }
  return data;
}
async function sendViaSmtp({ smtpUser, smtpPass, toEmail, formType, name, email, subject, message, pageUrl }) {
  const nodemailer = await import("nodemailer");
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: Number(process.env.SMTP_PORT || 465),
    secure: process.env.SMTP_SECURE !== "false",
    auth: { user: smtpUser, pass: smtpPass }
  });
  const emailSubject = subject || (formType === "newsletter" ? "Newsletter subscription \u2014 NutriThrive" : "Website contact \u2014 NutriThrive");
  const text = [
    `Type: ${formType}`,
    `Name: ${name || "(not provided)"}`,
    `Email: ${email}`,
    pageUrl ? `Page: ${pageUrl}` : "",
    "",
    message || "(newsletter signup \u2014 no message)"
  ].filter(Boolean).join("\n");
  await transporter.sendMail({
    from: `"NutriThrive Website" <${smtpUser}>`,
    to: toEmail,
    replyTo: email,
    subject: emailSubject,
    text
  });
}
async function handler(event) {
  const requestOrigin = String(getHeader(event, "origin") || "");
  const baseHeaders = {
    "Content-Type": "application/json",
    Vary: "Origin"
  };
  const headers = corsHeaders(requestOrigin, baseHeaders);
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (!requestOrigin || !ALLOWED_ORIGINS.has(requestOrigin)) {
    return {
      statusCode: 403,
      headers: baseHeaders,
      body: JSON.stringify({ error: "Origin not allowed" })
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const clientIp = getClientIp(event);
    if (isRateLimited(`send-form:${clientIp}`)) {
      return {
        statusCode: 429,
        headers,
        body: JSON.stringify({ error: "Too many requests" })
      };
    }
    const payload = JSON.parse(event.body || "{}");
    if (cleanText(payload.website, 200)) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ ok: true })
      };
    }
    const turnstileOk = await verifyTurnstile(
      cleanText(payload.turnstileToken, 2048),
      clientIp
    );
    if (!turnstileOk) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({
          error: "Verification failed. Please refresh the page and try again."
        })
      };
    }
    const formType = cleanText(payload.formType, 32) || "contact";
    const name = cleanText(payload.name, 200);
    const email = cleanText(payload.email, 320);
    const subject = cleanText(payload.subject, 300);
    const message = cleanText(payload.message, 8e3);
    const pageUrl = cleanText(payload.pageUrl, 500);
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Valid email is required" })
      };
    }
    if (formType === "contact" && !message) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Message is required" })
      };
    }
    const toEmail = process.env.FORM_EMAIL_TO || "nutrithrive0@gmail.com";
    const web3Key = process.env.WEB3FORMS_ACCESS_KEY;
    const smtpUser = process.env.SMTP_USER;
    const smtpPass = process.env.SMTP_PASS;
    const mailPayload = { toEmail, formType, name, email, subject, message, pageUrl };
    if (web3Key) {
      await sendViaWeb3Forms({ accessKey: web3Key, ...mailPayload });
    } else if (smtpUser && smtpPass) {
      await sendViaSmtp({ smtpUser, smtpPass, ...mailPayload });
    } else {
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({
          error: "Email delivery is temporarily unavailable. Please try again later.",
          fallback: "netlify-forms"
        })
      };
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ ok: true })
    };
  } catch (err) {
    console.error("[send-form]", err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to send message. Please try again or call 0438 201 419."
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});

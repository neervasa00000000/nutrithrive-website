var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var paypal_create_order_exports = {};
__export(paypal_create_order_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(paypal_create_order_exports);
var import_crypto = require("crypto");
const RATE_LIMIT_WINDOW_MS = 60 * 1e3;
const RATE_LIMIT_MAX_REQUESTS = 20;
const requestBuckets = /* @__PURE__ */ new Map();
function getHeader(event, key) {
  const headers = event?.headers || {};
  if (headers[key] !== void 0) return headers[key];
  const lower = key.toLowerCase();
  const found = Object.keys(headers).find((name) => name.toLowerCase() === lower);
  return found ? headers[found] : void 0;
}
function getClientIp(event) {
  const forwardedFor = String(getHeader(event, "x-forwarded-for") || "").split(",")[0].trim();
  const netlifyIp = String(getHeader(event, "x-nf-client-connection-ip") || "").trim();
  const fallback = String(event?.requestContext?.identity?.sourceIp || "").trim();
  return forwardedFor || netlifyIp || fallback || "unknown";
}
function isRateLimited(key, limit = RATE_LIMIT_MAX_REQUESTS, windowMs = RATE_LIMIT_WINDOW_MS) {
  const now = Date.now();
  const bucket = requestBuckets.get(key);
  if (!bucket || now - bucket.windowStart >= windowMs) {
    requestBuckets.set(key, { count: 1, windowStart: now });
    return false;
  }
  bucket.count += 1;
  return bucket.count > limit;
}
async function handler(event) {
  const requestOrigin = String(getHeader(event, "origin") || "");
  const allowedOrigins = /* @__PURE__ */ new Set([
    "https://nutrithrive.com.au",
    "https://www.nutrithrive.com.au"
  ]);
  const originAllowed = requestOrigin && allowedOrigins.has(requestOrigin);
  const baseHeaders = {
    "Content-Type": "application/json",
    "Vary": "Origin"
  };
  if (!originAllowed) {
    return {
      statusCode: 403,
      headers: baseHeaders,
      body: JSON.stringify({ error: "Origin not allowed" })
    };
  }
  const headers = {
    ...baseHeaders,
    "Access-Control-Allow-Origin": requestOrigin,
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const clientIp = getClientIp(event);
    if (isRateLimited(`paypal-create:${clientIp}`)) {
      return {
        statusCode: 429,
        headers,
        body: JSON.stringify({ error: "Too many requests" })
      };
    }
    const payload = JSON.parse(event.body || "{}");
    const { countryCode, items } = payload;
    const base = (process.env.PAYPAL_BASE || "https://api-m.paypal.com").replace(/\/$/, "");
    const client = process.env.PAYPAL_CLIENT_ID;
    const secret = process.env.PAYPAL_CLIENT_SECRET;
    if (!client || !secret) {
      console.error("[paypal-create-order] PayPal credentials not configured");
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({
          error: "Payment is temporarily unavailable. Please try again later."
        })
      };
    }
    if (!countryCode || typeof countryCode !== "string") {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Missing countryCode" })
      };
    }
    const cc = countryCode.trim().toUpperCase();
    if (!Array.isArray(items) || items.length < 1) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Missing items" })
      };
    }
    const PRODUCT_CATALOG = {
      "moringa-powder": { name: "100g Moringa", price: 11, weight: 100 },
      "moringa-200g": { name: "200g Moringa", price: 21.5, weight: 200 },
      "moringa-400g": { name: "3 + 1 = 400g Moringa", price: 35, weight: 400 },
      "moringa-soap": { name: "Moringa Soap", price: 7, weight: 95 },
      "moringa-soap-combo": { name: "Moringa 100g + Soap 95g", price: 17, weight: 195 },
      "curry-leaves": { name: "Dried Curry Leaves", price: 7, weight: 30 },
      "black-tea": { name: "Darjeeling Black Tea", price: 7.5, weight: 100 },
      "combo-pack": { name: "Premium Combo Pack", price: 17, weight: 130 },
      // Product page variations (cart ids are moringa-variation-1..6)
      "moringa-variation-1": { name: "3 + 1 = 400g Moringa", price: 35, weight: 400 },
      "moringa-variation-2": { name: "100g Moringa", price: 11, weight: 100 },
      "moringa-variation-3": { name: "Combo Moringa + Dried Curry Leaves", price: 17, weight: 130 },
      "moringa-variation-4": { name: "200g Moringa", price: 21.5, weight: 200 },
      "moringa-variation-5": { name: "30g Dried Curry Leaves", price: 7, weight: 30 },
      "moringa-variation-6": { name: "Moringa 100g + Soap 95g", price: 17, weight: 195 }
    };
    const shippingRatesModule = await import("../../scripts/global/shipping-rates.js");
    const ShippingRates = shippingRatesModule.default ?? shippingRatesModule;
    const tokenRes = await fetch(`${base}/v1/oauth2/token`, {
      method: "POST",
      headers: {
        "Authorization": "Basic " + Buffer.from(`${client}:${secret}`).toString("base64"),
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: "grant_type=client_credentials"
    });
    const tokenData = await tokenRes.json();
    if (!tokenRes.ok) throw new Error(JSON.stringify(tokenData));
    const currency = "AUD";
    let purchaseUnit;
    if (Array.isArray(items) && items.length > 0) {
      let computedSubtotal = 0;
      const cartItemsForShipping = [];
      const paypalItems = [];
      for (const item of items) {
        const id = String(item?.id ?? "").trim();
        const quantity = parseInt(item?.quantity ?? 1, 10);
        if (!id || !Number.isFinite(quantity) || quantity < 1 || quantity > 99) continue;
        const product = PRODUCT_CATALOG[id];
        if (!product) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: "Invalid item id" })
          };
        }
        computedSubtotal += product.price * quantity;
        cartItemsForShipping.push({
          id,
          name: product.name,
          weight: product.weight,
          quantity
        });
        paypalItems.push({
          name: String(product.name).substring(0, 127),
          quantity: String(quantity),
          unit_amount: {
            currency_code: currency,
            value: product.price.toFixed(2)
          }
        });
      }
      computedSubtotal = Number(computedSubtotal.toFixed(2));
      if (computedSubtotal <= 0 || paypalItems.length === 0) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "Invalid cart" })
        };
      }
      const shippingCostRaw = ShippingRates && typeof ShippingRates.calculate === "function" ? ShippingRates.calculate(cc, cartItemsForShipping, computedSubtotal) : null;
      const shippingCost = shippingCostRaw === null || shippingCostRaw === void 0 ? 0 : Number(shippingCostRaw);
      const totalNum = Number((computedSubtotal + shippingCost).toFixed(2));
      purchaseUnit = {
        amount: {
          currency_code: currency,
          value: totalNum.toFixed(2),
          breakdown: {
            item_total: {
              currency_code: currency,
              value: computedSubtotal.toFixed(2)
            },
            ...shippingCost > 0 ? {
              shipping: {
                currency_code: currency,
                value: shippingCost.toFixed(2)
              }
            } : {}
          }
        },
        items: paypalItems
      };
    } else {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Missing items" })
      };
    }
    const orderRes = await fetch(`${base}/v2/checkout/orders`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${tokenData.access_token}`
      },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [purchaseUnit],
        application_context: {
          shipping_preference: "GET_FROM_FILE",
          // Requires buyer to provide shipping address
          user_action: "PAY_NOW",
          // Shows "Pay Now" button instead of "Continue"
          payment_method: {
            payer_selected: "PAYPAL",
            payee_preferred: "IMMEDIATE_PAYMENT_REQUIRED"
          }
        }
      })
    });
    const order = await orderRes.json();
    if (!orderRes.ok) throw new Error(JSON.stringify(order));
    const captureToken = (0, import_crypto.createHmac)("sha256", secret).update(String(order.id)).digest("hex");
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ orderID: order.id, captureToken })
    };
  } catch (err) {
    console.error("[paypal-create-order]", err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Unable to create order. Please try again."
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
